import { Component, ViewChild } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { GamesComponent } from './games/games.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, GamesComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  @ViewChild(GamesComponent) gamesComponent!: GamesComponent;

  username = '';
  isLoggedIn = false;

  onLogin(inputUsername: string):void{
    if(inputUsername.trim()!== ''){
      this.username = inputUsername;
      this.isLoggedIn = true;
    }else{
      alert('Por favor, ingrese un nombre de usuario válido');
    }
  }

  onLogout():void{
    this.username = '';
    this.isLoggedIn = false;
  }

  


  addGame() {
    const nameInput = document.getElementById('name') as HTMLInputElement;
    const yearInput = document.getElementById('year') as HTMLInputElement;
    
    const name = nameInput.value;
    const year = parseInt(yearInput.value, 10);
    
    if (name && !isNaN(year)) {
      this.gamesComponent.addGame(name, year);
      
      // Limpiar los campos después de agregar el juego
      nameInput.value = '';
      yearInput.value = '';
    } else {
      alert('Por favor, ingrese un nombre y un año válido');
    }
  }

  editGame(id: number) {
    console.log(id);
  }
}